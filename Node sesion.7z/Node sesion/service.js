var express = require('express');
var http = require('http');
var cors = require('cors');
var exp = express();
var fs = require('fs');
var MongoClient = require('mongodb').MongoClient
var parser = require('body-parser');

exp.get("/rest/api/load", cors(), (req, res) => {
    console.log('Load Invoked');
    res.send({ msg: 'Give Some rest to the world' });

});


exp.route('/rest/api/get', cors()).get((req, res) => {
    console.log("Get Invoked");
    res.send({ msg: 'Hello World' });

    MongoClient.connect('mongodb://localhost:27017/test', function (err, db) {
        if (err) throw err;
        var dbo = db.db('test');
        dbo.collection('test').find({}).toArray(function (err, result) {
            if (err) throw err;
            console.log(result);
            db.close();
        });
    });

});

exp.use(parser.json());

exp.route('/rest/api/post', cors()).post((req, res) => {
    console.log(req.body);
    fs.writeFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);

    //to connect to  data base
    MongoClient.connect('mongodb://localhost:27017/test', function (err, db) {
        if (err) throw err;
        var dbo = db.db('test');
        dbo.collection('test').insertOne(req.body, true, function (err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            db.close();
        });
    });
});

exp.route('/rest/api/get/:name').get((req, res) => {
    res.send("Hello World" + req.params['name']);
});

exp.route('/rest/api/put').post((req, res) => {
  
    console.log("delete invoked");
    MongoClient.connect('mongodb://localhost:27017/test', function (err, db) {
        if (err) throw err;
  var dbo = db.db("test");
  var myquery = { name:"Usa" };
  var newvalues = { $set: {age:"56" } };
  dbo.collection("test").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("1 document updated");
    db.close();
  });
});

});

exp.route('/rest/api/delete').post((req, res) => {
    res.send("Deleted");
    console.log("Delete");
    console.log(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function (err, db) {
        if (err) throw err;
        var dbo = db.db('test');
        dbo.collection('test').deleteOne(req.body, function (err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            db.close();
        });
    });
});


exp.listen(3000);