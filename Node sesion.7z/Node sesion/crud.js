var express = require('express');
var http = require('http');
var cors = require('cors');
var exp = express();
var fs = require('fs');
var MongoClient = require('mongodb').MongoClient
var parser = require('body-parser');

exp.get("/rest/api/load", cors(), (req, res) => {
    console.log('Load Invoked');
    res.send({ msg: 'Give Some rest to the world' });
});


exp.route('/rest/api/get', cors()).get((req, res) => {
    console.log("Get Invoked");
    res.send({ msg: 'Hello World' });
});

exp.use(parser.json());

exp.route('/rest/api/post', cors()).post((req, res) => {
    console.log(req.body);
    fs.writeFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);

});
exp.route('/rest/api/get/:name').get((req, res) => {
    res.send("Hello World" + req.params['name']);
});

exp.route('/rest/api/put').put((req, res) => {
    fs.writeFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);
    console.log(req.body);
});

exp.route('/rest/api/delete').delete((req, res) => {
    res.send("Hello World");
});

exp.listen(3000);