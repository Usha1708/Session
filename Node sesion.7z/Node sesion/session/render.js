var exp = require ('express');
var view = exp();

view.set("view engine","jade");
view.get("/jade",function(req,res){
    res.render('sample');
});

view.listen(3002,()=>{
    console.log('Jade RUNNING');
})