import { Component, OnInit } from '@angular/core';
import { MainServiceService } from './main-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'Angular - Node';
  uname: string;
  data: string;
  age: number;
  dage:number;
  dname:string;
  aage:number;
  aname:string;
  constructor(private call: MainServiceService) {

  }
  invokePost() {
    console.log(this.uname, this.age);
    this.call.postData(this.uname, this.age).subscribe((data: any) => {

    });
  }
  ngOnInit(): void {
    this.getInvoke();

  }
  getInvoke() {
    this.call.getLoad().subscribe((data: any) => this.data = data.msg);
  }

  invokeGet()
  {
    this.call.getGet().subscribe((data: any) => this.data = data.msg);
  }

  invokeDelete()
  {
    this.call.getDelete(this.dname,this.dage).subscribe((data: any) => {

    });

  }

  invokeUpdate()
  {
    this.call.getUpdate(this.aname,this.aage).subscribe((data: any) => {
      
    });
  }

}