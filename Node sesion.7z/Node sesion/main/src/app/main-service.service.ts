import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainServiceService {
  constructor(private http: HttpClient) { }

  getLoad() {
    return this.http.get("http://localhost:3000/rest/api/load");
  }

  getGet()
  {
    return this.http.get("http://localhost:3000/rest/api/get");
  }

  postData(ename: string, eage: number): Observable<any> {
    console.log("ENAME:" + ename);
    console.log("EAGE:" + eage);
    return this.http.post('http://localhost:3000/rest/api/post', {
      name: ename,
      age: eage
    });
  }

  getDelete(kname:string,kage:number): Observable<any>
  {
     if(kname){
        kname = undefined;
      }
    console.log(" Deleted Age value " +kage);
    return this.http.post("http://localhost:3000/rest/api/delete",{
     
      name:kname,
      age:kage
    });
  }
 getUpdate(bname: string, bage: number): Observable<any> {
    return this.http.post('http://localhost:3000/rest/api/put', {
      name: bname,
      age: bage
    });
  }

}
