/*var add = require('./lib/add');


console.log("--------Welcome to NODE js---------");

add.addData();
add.getData();

var pro = require('./lib/product');


console.log("--------Welcome to NODE js---------");

var prodOne = new pro.prod(1001,"Moblie",566984);
var prodTwo = new pro.prod(1002,"Rice",200);
var prodThree = new pro.prod(1003,"TV",56614);

pro.set(prodOne);
pro.set(prodTwo);
pro.set(prodThree);

pro.display();
pro.sortData();*/

var buff = new Buffer(18);
buff.write("Capgemini");
console.log(buff);
console.log(buff.toString());
console.log(buff.toJSON());

var buf = new Buffer([1,5,18]);
console.log(buf);
buf.write("Capgemini");
console.log(buf);
console.log(buf.toString());

var b = new Buffer("Capgemini","utf-8");
console.log(b);