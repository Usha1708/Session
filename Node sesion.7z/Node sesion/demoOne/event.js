var event =require('events'); //core modules of node

var myEvent = new event.EventEmitter();

//Registering of event --display (event name)
myEvent.on("display",function(msg,msg1){
    setTimeout(function(){
        console.log("After timeOut");
    },6000);
    console.log("In event display >>>>>",msg,msg1);
    
});

myEvent.on("dis",function(temp){
    console.log("In event dis >>>>>",temp);
});


myEvent.emit("display","Capgemini =>","Good Company");
myEvent.emit("dis","Node JS");