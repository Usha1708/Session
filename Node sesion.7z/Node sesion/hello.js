/*var http = require('http');

http.createServer(function(req,res)
{
    res.writeHead(200,{'Content-Type' : 'text/plain'});
    res.write("Hello World..!!!!");
    res.end();
}).listen(3000)

var x = (req,res) => 
{
    res.writeHead(200,{'Content-Type' : 'text/plain'});
    res.write("Hello World function....!!!!");
    res.end();
}

http.createServer(x).listen(3002)*/

var http = require('http');

//var qs = require('querystring');
//var url = require('url');

var express = require('express');//imports exports library

var exp = express();//instance of export

var x = exp.get('/get', function (req, res) { //invoking get method in which url is defined
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write("<h1>SOME GET 1</h1>" + req.query.id);
    res.end();
});
var y = exp.post('/submit', function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write("<h1>SOME GET</h1>");
    res.end();
});

http.createServer(x).listen(3002);
http.createServer(y).listen(3004);